package Fungsi;
//Nama	: Muhammad Azhar Utama
//NRP	: 223040077
public class contohFungsi {
	
	// Ini adalah fungsi untuk melakukan penjumlahan
	public static int tambah(int a, int b) {
		return a + b;
	}
	
	// Ini adalah fungsi untuk melakukan perkalian
	public static int kali(int a, int b) {
		return a * b;
	}

	public static void main(String[] args) {
		// Memanggil fungsi tambah
		int hasilPenjumlahan = tambah(5, 3);
		System.out.println("Hasil penjumlahan = " + hasilPenjumlahan);
		
		// Memanggil fungsi kali
		int hasilPerkalian = kali(4, 6);
		System.out.println("Hasil perkalian = " + hasilPerkalian);
	}
}


//Hasil penjumlahan = 8
//Hasil perkalian = 24
