package latihan3;

public class ListTest2 {
	public static void main(String[] args) {

        StrukturList myList = new StrukturList();

        myList.addTail(3);
        myList.addTail(2);
        myList.addTail(1);
        myList.addTail(7);
        myList.displayElement();;
	}
}
