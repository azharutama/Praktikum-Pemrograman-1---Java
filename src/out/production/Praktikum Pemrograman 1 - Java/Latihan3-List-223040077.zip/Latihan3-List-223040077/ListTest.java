package latihan3;

public class ListTest {
	public static void main(String[] args) {
        // Create list dengan keyword new
        StrukturList myList = new StrukturList();

        myList.addTail(3);
        myList.addTail(4);
        myList.addTail(5);
        myList.displayElement();;
    }

}
